# Checkpoint 1 Reflection

## What feature did you implement? I implemented
Feature 1: Create and display a solved Rubik's Cube using a Cube class and CubeManager.

## What went well?
Once I figured out what part to implement first everything went smooth, Creating Cube, and moves.

## What challenges did I face? I ran into a few Cmake errors, filepath errors, and a few test errors until I got it right.

## What did you learn?
- I learned about things like multi-file in C++, enums, Ctest, and pathways.

## What are my next steps for the final project?
- Future features: cube rotations, checking if solved, AI, Cube upgrades.
