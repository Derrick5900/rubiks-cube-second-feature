# Checkpoint 2 Reflection

## What I Implemented
I implemented a second feature that rotates a chosen face of the cube (U, D, L, R, F, B) clockwise or counter-clockwise and then displays the updated cube.

## How It Integrates with my First Feature
The first feature creates a solved cube and displays all faces. The second feature uses that same cube and modifies it. The user must create the cube (option 1) before using the rotate feature (option 2).

## Challenges Faced
had plenty of compile error's and program error's before finally getting right.
moves, applied everytime cube is rotated.
design choices, rotation logic.

## What I Learned
I learned alot about enums and 2D arrays, classes, and separating logic (Cube) from user input (CubeManager).

## Testing Results